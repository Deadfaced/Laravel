<footer>
    <p align="center">This is a footer</p>
</footer><?php /**PATH C:\Users\Claudio\Documents\ATEC\Laravel\PlayerDatabase\player\resources\views/master/footer.blade.php ENDPATH**/ ?>