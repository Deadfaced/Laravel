<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <?php $__env->startComponent('components.table', [
    'players' => $players,
    ]); ?>



    <?php if (isset($__componentOriginal5ad86af2593af3d361eefeb5c9b20eef4f4dddc3)): ?>
<?php $component = $__componentOriginal5ad86af2593af3d361eefeb5c9b20eef4f4dddc3; ?>
<?php unset($__componentOriginal5ad86af2593af3d361eefeb5c9b20eef4f4dddc3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Claudio\Documents\ATEC\Laravel\PlayerDatabase\player\resources\views/players.blade.php ENDPATH**/ ?>