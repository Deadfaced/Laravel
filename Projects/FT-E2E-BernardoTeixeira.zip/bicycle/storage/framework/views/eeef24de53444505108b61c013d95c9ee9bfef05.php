<?php $__env->startSection('content'); ?>


<table class="table table-dark">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">User ID</th>
        <th scope="col">Brand</th>
        <th scope="col">Model</th>
        <th scope="col">Color</th>
        <th scope="col">Price</th>
      </tr>
    </thead>

    <tbody>

        <?php $__currentLoopData = $bicycles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bicycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($bicycle->id); ?></td>
                <td><?php echo e($bicycle->user->id); ?></td>
                <td><?php echo e($bicycle->brand); ?></td>
                <td><?php echo e($bicycle->model); ?></td>
                <td><?php echo e($bicycle->color); ?></td>
                <td><?php echo e($bicycle->price); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bttei\Documents\ATEC\Atec-modulos\PHP\Laravel\Projects\bicycle\resources\views/bicycle.blade.php ENDPATH**/ ?>