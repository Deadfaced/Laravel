<footer>
    <p align="center">This is a footer</p>
</footer>
<?php /**PATH C:\Users\bttei\Documents\ATEC\Atec-modulos\PHP\Laravel\Projects\bicycle\resources\views/master/footer.blade.php ENDPATH**/ ?>