<footer>
    <p align="center">This is a footer</p>
</footer>
