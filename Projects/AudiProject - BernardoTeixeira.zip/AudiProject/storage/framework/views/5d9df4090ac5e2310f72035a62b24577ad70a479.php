<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://picsum.photos/1500/700" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
            <img src="https://picsum.photos/1500/700" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
            <img src="https://picsum.photos/1500/700" class="d-block w-100" alt="...">
        </div>
    </div>
</div>
<?php /**PATH C:\Users\bttei\Documents\ATEC\Modulos\AtecModulos\PHP\Laravel\Projects\AudiProject\resources\views/components/carousel.blade.php ENDPATH**/ ?>