<div class="col mt-3" style="display: flex; justify-content: center; align-items: center">
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut commodi nam quo unde. Ducimus, obcaecati, repellendus? Corporis deserunt dolor est officia quasi quia quo repellendus, repudiandae, sapiente similique veritatis, voluptates?
    </p>
    <img src="https://cf-cdn-v5.audi.at/media/Theme_Menu_Model_Dropdown_Item_Image_Component/root-pt-model-modelMenu-editableItems-73240-dropdown-476801-image/dh-500-a0e9a6/3203b915/1675150917/audi-a7-sportback-tfsi-e-frontansicht.jpg" alt="">
</div>
<?php /**PATH C:\Users\bttei\Documents\ATEC\Modulos\AtecModulos\PHP\Laravel\Projects\AudiProject\resources\views/components/textImage/textImage.blade.php ENDPATH**/ ?>