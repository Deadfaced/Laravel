<div class="container" style="display: flex; justify-content: center; align-items: center">


    <div class="row">
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
    </div>

    <div class="row">
        <div class="col">
            <img class="w-100" src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
    </div>
</div>
<?php /**PATH C:\Users\bttei\Documents\ATEC\Modulos\AtecModulos\PHP\Laravel\Projects\AudiProject\resources\views/gallery/gallery.blade.php ENDPATH**/ ?>