<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="row">


            <?php $__env->startComponent('components.carousel.carousel'); ?>

            <?php if (isset($__componentOriginal61a2b1f0efc5e8bb87392c61d7999e03bfbad6a1)): ?>
<?php $component = $__componentOriginal61a2b1f0efc5e8bb87392c61d7999e03bfbad6a1; ?>
<?php unset($__componentOriginal61a2b1f0efc5e8bb87392c61d7999e03bfbad6a1); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


        </div>

    </div>

    <div class="container">
        <div class="row">
            <div class="col">
                <?php $__env->startComponent('components.cards.card'); ?>

                <?php if (isset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8)): ?>
<?php $component = $__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8; ?>
<?php unset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
            <div class="col">
                <?php $__env->startComponent('components.cards.card'); ?>

                <?php if (isset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8)): ?>
<?php $component = $__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8; ?>
<?php unset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
            <div class="col">
                <?php $__env->startComponent('components.cards.card'); ?>

                <?php if (isset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8)): ?>
<?php $component = $__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8; ?>
<?php unset($__componentOriginalaa07d5ea3fd65d5f29b28d37b0cadc1bcfcc05f8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
        </div>
    </div>

    <div class="container mt-3">
        <div class="row mt-3">
                <?php $__env->startComponent('components.textImage.textImage'); ?>

                <?php if (isset($__componentOriginal222633cd93a435e603a0d1e1fd8aba4433d95e69)): ?>
<?php $component = $__componentOriginal222633cd93a435e603a0d1e1fd8aba4433d95e69; ?>
<?php unset($__componentOriginal222633cd93a435e603a0d1e1fd8aba4433d95e69); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


                <?php $__env->startComponent('components.textImage.imageText'); ?>

                <?php if (isset($__componentOriginal1f393f51e05addd9123ff8fc2dae2f29689355fa)): ?>
<?php $component = $__componentOriginal1f393f51e05addd9123ff8fc2dae2f29689355fa; ?>
<?php unset($__componentOriginal1f393f51e05addd9123ff8fc2dae2f29689355fa); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>
    </div>

    <div class="container">

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bttei\Documents\ATEC\Modulos\AtecModulos\PHP\Laravel\Projects\AudiProject\resources\views/audi/index.blade.php ENDPATH**/ ?>