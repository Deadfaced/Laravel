
<div class="col mt-3" style="display: flex; justify-content: center; align-items: center">
    <img src="https://s2.glbimg.com/hnhyYmh8G_pvrhVbijbtMBPj5SA=/620x350/e.glbimg.com/og/ed/f/original/2021/08/16/210810130708-embargo-restricted-01-audi-sky-sphere-concept-exlarge-169.jpg" alt="">
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut commodi nam quo unde. Ducimus, obcaecati, repellendus? Corporis deserunt dolor est officia quasi quia quo repellendus, repudiandae, sapiente similique veritatis, voluptates?
    </p>
</div>
