<div class="container" style="display: flex; justify-content: center; align-items: center">


    <div class="row">
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
    </div>

    <div class="row">
        <div class="col">
            <img class="w-100" src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
        <div class="col">
            <img class="w-100"  src="https://www.turbo.pt/wp-content/uploads/2020/03/AudiA3NG2020_diagofrte.jpg" alt="">
        </div>
    </div>
</div>
