<footer>
    <p align="center">Bernardo Teixeira ™</p>
</footer>
