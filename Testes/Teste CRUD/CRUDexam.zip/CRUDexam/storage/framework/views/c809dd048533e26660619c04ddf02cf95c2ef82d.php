<footer>
    <p align="center">Bernardo Teixeira ™</p>
</footer>
<?php /**PATH C:\Users\berna\Documents\ATEC\Módulos\Atec-modulos\PHP\Laravel\Testes\Teste CRUD\CRUDexam\resources\views/master/footer.blade.php ENDPATH**/ ?>