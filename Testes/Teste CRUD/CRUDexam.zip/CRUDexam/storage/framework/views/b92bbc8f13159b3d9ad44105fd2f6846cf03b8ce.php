<table class="table">
    <thead class="thead-dark">
    <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Details</th>
        <th scope="col">Category</th>
        <th scope="col">Project</th>
        <th scope="col"class="d-flex justify-content-center">Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($product->id); ?></th>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->details); ?></td>
            <td><?php echo e($product->category->name); ?></td>
            <td><?php echo e($product->project->name); ?></td>

            <td class="d-flex justify-content-center">
                <a class="btn btn-primary mr-2" href="<?php echo e(route('product.show', $product->id)); ?>">Show</a>
            <a class="btn btn-success mr-2" href="<?php echo e(route('product.edit', $product->id)); ?>">Edit</a>
            <form method="post" action="<?php echo e(route('product.destroy', $product->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger" type="submit">Delete</button>
            </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\berna\Documents\ATEC\Módulos\Atec-modulos\PHP\Laravel\Testes\Teste CRUD\CRUDexam\resources\views/components/Product/table.blade.php ENDPATH**/ ?>