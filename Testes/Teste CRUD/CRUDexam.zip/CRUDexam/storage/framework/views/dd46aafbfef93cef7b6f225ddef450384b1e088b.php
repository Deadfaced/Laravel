<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <a class="btn btn-primary mb-3" href="<?php echo e(route('project.create')); ?>">Create</a>
        <?php $__env->startComponent('components.Project.table', [
            'projects' => $projects,
            ]); ?>
        <?php if (isset($__componentOriginal049c139a91f9edfbd34ca4fe309b5f5c4f555b9d)): ?>
<?php $component = $__componentOriginal049c139a91f9edfbd34ca4fe309b5f5c4f555b9d; ?>
<?php unset($__componentOriginal049c139a91f9edfbd34ca4fe309b5f5c4f555b9d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\berna\Documents\ATEC\Módulos\Atec-modulos\PHP\Laravel\Testes\Teste CRUD\CRUDexam\resources\views/pages/Project/index.blade.php ENDPATH**/ ?>