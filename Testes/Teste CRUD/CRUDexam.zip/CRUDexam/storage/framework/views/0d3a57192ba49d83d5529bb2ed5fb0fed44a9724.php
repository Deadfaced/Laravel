<?php $__env->startSection('content'); ?>
    <div class="container">
        <a class="btn btn-primary mb-3" href="<?php echo e(route('product.create')); ?>">Create</a>
        <?php $__env->startComponent('components.Product.table', [
            'products' => $products,
            ]); ?>
        <?php if (isset($__componentOriginal1082a4632ea6c54605c34fefc4fd3927a8b323bb)): ?>
<?php $component = $__componentOriginal1082a4632ea6c54605c34fefc4fd3927a8b323bb; ?>
<?php unset($__componentOriginal1082a4632ea6c54605c34fefc4fd3927a8b323bb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\berna\Documents\ATEC\Módulos\Atec-modulos\PHP\Laravel\Testes\Teste CRUD\CRUDexam\resources\views/pages/Product/index.blade.php ENDPATH**/ ?>