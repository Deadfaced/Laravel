<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <a class="btn btn-primary mb-3" href="<?php echo e(route('category.create')); ?>">Create</a>
        <?php $__env->startComponent('components.Category.table', [
            'categories' => $categories,
            ]); ?>
        <?php if (isset($__componentOriginal54347e9cf1359d961b5cdb77045863b7c4d1272b)): ?>
<?php $component = $__componentOriginal54347e9cf1359d961b5cdb77045863b7c4d1272b; ?>
<?php unset($__componentOriginal54347e9cf1359d961b5cdb77045863b7c4d1272b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\berna\Documents\ATEC\Módulos\Atec-modulos\PHP\Laravel\Testes\Teste CRUD\CRUDexam\resources\views/pages/Category/index.blade.php ENDPATH**/ ?>